// package types;
//
// public class Argument
// {
// 	private String name;
// 	private Type type;
//
// 	public Argument(String name, Type type)
// 	{
// 		this.name = name;
// 		this.type = type;
// 	}
//
// 	public String name() { return this.name; }
// 	public Type type() { return this.type; }
// }
