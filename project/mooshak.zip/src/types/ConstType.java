package types;

public enum ConstType
{
	DOUBLE,
	STRING,
}
